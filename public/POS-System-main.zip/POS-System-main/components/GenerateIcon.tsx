

const GenerateIcon = () => {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      className="injected-svg"
      data-src="https://cdn.hugeicons.com/icons/google-gemini-solid-sharp.svg?v=1.0.1"
    //   xmlns:xlink="http://www.w3.org/1999/xlink"
      role="img"
      color="#000000"
    >
      <path
        d="M3 11.25C7.55635 11.25 11.25 7.55635 11.25 3H12.75C12.75 7.55635 16.4437 11.25 21 11.25V12.75C16.4437 12.75 12.75 16.4437 12.75 21H11.25C11.25 16.4437 7.55635 12.75 3 12.75V11.25Z"
        fill="#000000"
      ></path>
    </svg>
  );
};

export default GenerateIcon;
